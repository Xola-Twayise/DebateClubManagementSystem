﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DebateClubManagementSystem.Data.Migrations
{
    /// <inheritdoc />
    public partial class updatedsetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AttendanceConfirmation",
                table: "Member");

            migrationBuilder.DropColumn(
                name: "DebateTrainer",
                table: "Member");

            migrationBuilder.AddColumn<bool>(
                name: "AttendanceConfirmation",
                table: "Debate",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "DebateTrainer",
                table: "Debate",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AttendanceConfirmation",
                table: "Debate");

            migrationBuilder.DropColumn(
                name: "DebateTrainer",
                table: "Debate");

            migrationBuilder.AddColumn<bool>(
                name: "AttendanceConfirmation",
                table: "Member",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "DebateTrainer",
                table: "Member",
                type: "nvarchar(255)",
                maxLength: 255,
                nullable: false,
                defaultValue: "");
        }
    }
}

