﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using DebateClubManagementSystem.Models;

namespace DebateClubManagementSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<DebateClubManagementSystem.Models.Member> Member { get; set; } = default!;
        public DbSet<DebateClubManagementSystem.Models.Admin> Admin { get; set; } = default!;
        public DbSet<DebateClubManagementSystem.Models.Event> Event { get; set; } = default!;
        public DbSet<DebateClubManagementSystem.Models.Debate> Debate { get; set; } = default!;

      
    }
}
