user Username : twayisexola@gmail.com
password : #Xola123

ADMIN USERNAME : admin@madibaz.com
Password : #Qwert321

but you can be able to register your own credentials from the register page

TECH STACK USED : ASP.NET CORE MVC, C# , HTML,CSS, BOOTSRAP , Javascript 
Database : MySQL

authentication and authorisation >>
Anonymus user can only view the home page and also the about page , when they click the other pages it will send them to the login page
Regualr users can view all pages however they cant delete the member table
admin have access to create and deleted

special features
courusal of images in home page and also text infomation in about page
validation of all input fields
hover effect on mouse
all CRUD FUNCTIONALITIES WORK COMPLETELY

