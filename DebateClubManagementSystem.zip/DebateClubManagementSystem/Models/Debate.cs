﻿namespace DebateClubManagementSystem.Models
{
    public class Debate
    {
        public int Id { get; set; }
        public string Topic { get; set; }

        public DateTime Date { get; set; }
        public string DebateTrainer { get; set; }
        public bool AttendanceConfirmation { get; set; }
    }
}
